var num = +prompt("Enter the number to check");
if (num % 2 === 0) {
    alert("You entered an Even number");
}
else {
    alert("You entered an Odd number");
}