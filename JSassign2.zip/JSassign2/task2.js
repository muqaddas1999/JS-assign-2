var clr = prompt("Enter the color of road traffic signals:");
if (clr == "Red") {
    alert("Must Stop");
}
if (clr == "Yellow") {
    alert("Ready to move");
}
if (clr == "Green") {
    alert("Move now");
}