var city = prompt("Enter Your city name" , "Karachi");
if (city === "Karachi") {
    alert("Welcome to city of lights");
}