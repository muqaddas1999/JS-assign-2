var ch = prompt("Enter any Character" , "a , b , c ,...");
if (ch == "a" || ch == "A"  || ch == "e" || ch == "E" || ch == "i" || ch == "I" || ch == "o" || ch == "O" || ch == "u" || ch == "U") {
    alert("True");
} else {
    alert("False");
}